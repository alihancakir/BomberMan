import pygame

pygame.init()

screen = pygame.display.set_mode((500, 500))
font25= pygame.font.Font(None, 25)

count=0

bomb_x=""
bomb_y=""
bomb_turn=""

default_bomb_info=[]

enter_toggle_flag=False

color_x="blue"
color_y="black"
color_turn="black"

fail_log=""

running = True
while running:
    screen.fill("white")
    default_bomb_header =font25.render(f"please add default bomb", True, "black")
    screen.blit(default_bomb_header, (100, 20))

    default_bomb_header2 =font25.render(f"{fail_log}", True, "red")
    screen.blit(default_bomb_header2, (100, 50))

    for  event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            
            #delete
            if event.key == pygame.K_BACKSPACE:

                if  len(bomb_x)<3:
                    bomb_x=""

                elif len(bomb_turn)==0 and len(bomb_x)==3 and len(bomb_y)<3:
                    bomb_y=""

            if pygame.K_0 <= event.key <= pygame.K_9:
                
                #bomb_x
                if len(bomb_x)<3:
                    bomb_x+=chr(event.key)

                    if len(bomb_x)==3:
 
                        if int(bomb_x)%40 != 0:
                                fail_log="(bomb_x and bomb_y must be multiples of 40)"
                                color_x="red"
                                bomb_x=""

                        else: 
                            fail_log=""
                            color_x= (92,209,20)
                            color_y="blue"
                            
                    else:
                        color_y="black"
                        color_turn="black"

                #bomb_turn
                elif len(bomb_turn)==0 and len(bomb_x)==3 and len(bomb_y)==3:
                    bomb_turn+=chr(event.key)

                    if int(bomb_x)%40==0 and int(bomb_y)%40==0:
                        default_bomb_info.append([int(bomb_x),int(bomb_y),int(bomb_turn)])
                    
                        bomb_x=""
                        bomb_y=""
                        bomb_turn=""

                        color_x="black"
                        color_y="black"
                        color_turn="black"
                #bomb_y
                elif len(bomb_x)==3 and len(bomb_y)<3:

                    color_y=(92,209,20)
                   
                    bomb_y+=chr(event.key)

                    if len(bomb_y)==3:
                        
                        if int(bomb_y)%40 != 0:
                                fail_log="(bomb_x and bomb_y must be multiples of 40)"
                                color_y="red"
                                bomb_y=""

                        else:
                            color_turn="blue"                            
                            fail_log=""
                            color_y=(92,209,20)
                            
                print(f"dizi:{default_bomb_info} {bomb_x},{bomb_y},{bomb_turn},{count}")

    default_bomb_x =font25.render(f"default bomb x:{bomb_x}", True, color_x)
    screen.blit(default_bomb_x, (150, 120))
    default_bomb_y =font25.render(f"default bomb y:{bomb_y}", True, color_y)
    screen.blit(default_bomb_y, (150, 140))
    default_bomb_turn =font25.render(f"default bomb turn:{bomb_turn}", True, color_turn)
    screen.blit(default_bomb_turn, (150, 160))

    default_bomb =font25.render(f"{default_bomb_info}", True, "black")
    screen.blit(default_bomb, (150, 80))

    pygame.display.flip()

pygame.quit()
